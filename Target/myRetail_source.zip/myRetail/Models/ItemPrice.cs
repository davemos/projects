﻿namespace myRetail.Models
{
    public class ItemPrice
    {
        public decimal value { get; set; }
        public string currency_code { get; set; }
    }
}